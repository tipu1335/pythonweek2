# split method
# name,age = input("Enter your name and age: ").split(',')
# print(name)
# print(age)

# join method
user_info= ['Satakratu','24']
print(','.join(user_info))