fruits = ['Orange','apple','grapes','banana']
# for loop
# for fruit in fruits:
  #  print(fruit)

# while loop
i = 0
while i < len(fruits):
    print(fruits[i])
    i+=1