# compare lists
fruits1= ['apple','banana','kiwi']
fruits3= ['apple','banana','kiwi']
fruits2= ['orange','apple','grapes','pear']
print(fruits1==fruits3)
print(fruits1 is fruits3)