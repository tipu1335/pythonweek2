# update method

user_info={
    'name':'harshit',
    'age': 24,
    'fav_movies': ['coco'],
    'fav_tunes': ['awakening','fairy tale'],
}

more_info= {'state' : 'haryana', 'hobbies' : ['coding','reading','guiter']}
user_info.update({})
print(user_info)