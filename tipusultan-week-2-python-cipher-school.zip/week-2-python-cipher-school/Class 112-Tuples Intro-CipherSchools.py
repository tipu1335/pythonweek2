# tuple data structure
# tuple can store any data type
# most important tuples are immutable, once tuple is created you can't update it
# data inside tuple
example = ('one','two','three')
# no append, no insert, no pop, no remove
# days = ('monday','tuesday')
# tuples are faster than lists
# methods
# count, index
# len function
# slicing
# print(example[:2])
example[0] = 1
print(example)