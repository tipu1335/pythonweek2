# something more about tuples, list, str
# nums = tuple(range(1,11))
nums = list((1,2,3,4,5,6,7,8,9,0,))
print(nums)
print(type(nums))