# more about get method
user= {'name' : 'harshit', 'age' : '24', 'age' : '34'}
# print(user.get('names','not found'))
print(user)