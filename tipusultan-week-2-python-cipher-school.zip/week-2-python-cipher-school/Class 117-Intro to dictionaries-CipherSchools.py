# dictonaries intro

# how to create dictonaries
# step 1
user = {'name':'harshit','age': 24}
# print(user)
# print(type(user))
user1=dict(name='Harshit', age= 24)
# print(user1)
# how to acess data from dictonary
# print(user['name'])
# print(user['age'])
# which type of data can dictonary store?
# anything

user_info={
    'name':'harshit',
    'age': 24,
    'fav_movies': ['coco'],
    'fav_tunes': ['awakening','fairy tale'],




}
# print(user_info['fav_tunes'])

# How to add data to empty dictonary
user_info2= {}
user_info2['name']='mohit'
print(user_info2)